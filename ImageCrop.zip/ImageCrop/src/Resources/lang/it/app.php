<?php 

return [
    'imagecrop' => [
        'cancel' => 'Annulla',
        'crop'  => 'Ritaglia',
    ],
];
