<?php

return [
    'imagecrop' => [
        'cancel' => 'Отмена',
        'crop'  => 'Обрезать',
    ],
];
