<?php

return [
    'imagecrop' => [
        'cancel' => 'Abbrechen',
        'crop'  => 'Zuschneiden',
    ],
];

