<?php

return [
    'imagecrop' => [
        'cancel' => 'Cancelar',
        'crop'  => 'Recortar',
    ],
];

