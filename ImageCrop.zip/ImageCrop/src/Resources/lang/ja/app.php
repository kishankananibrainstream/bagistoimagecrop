<?php

return [
    'imagecrop' => [
        'cancel' => 'キャンセル',
        'crop'  => '切り取り',
    ],
];
