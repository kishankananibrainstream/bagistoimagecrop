<?php

return [
    'imagecrop' => [
        'cancel' => 'අවලංගු කරන්න',
        'crop'  => 'අවලංගු කරන්න',
    ],
];

