<?php

return [
    'imagecrop' => [
        'cancel' => 'Cancelar',
        'crop'  => 'Cortar',
    ],
];
