<?php

return [
    'imagecrop' => [
        'cancel' => 'Anuluj',
        'crop'  => 'Przytnij',
    ],
];
