<?php

return [
    'imagecrop' => [
        'cancel' => 'Скасувати',
        'crop'  => 'Обрізати',
    ],
];

