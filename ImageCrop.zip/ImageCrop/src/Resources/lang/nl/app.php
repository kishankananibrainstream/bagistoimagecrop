<?php

return [
    'imagecrop' => [
        'cancel' => 'Annuleren',
        'crop'  => 'Bijsnijden',
    ],
];
