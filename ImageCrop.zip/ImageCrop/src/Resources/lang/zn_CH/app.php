<?php

return [
    'imagecrop' => [
        'cancel' => '取消',
        'crop'  => '裁剪',
    ],
];

