<?php

return [
    'imagecrop' => [
        'cancel' => 'বাতিল করুন',
        'crop'  => 'কৃষ্ণণ',
    ],
];
