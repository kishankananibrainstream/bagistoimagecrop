<?php

return [
    'imagecrop' => [
        'cancel' => 'Cancel',
        'crop'  => 'Crop',
    ],
];