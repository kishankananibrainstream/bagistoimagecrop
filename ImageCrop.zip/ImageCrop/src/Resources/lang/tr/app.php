<?php

return [
    'imagecrop' => [
        'cancel' => 'İptal',
        'crop'  => 'Kırp',
    ],
];

