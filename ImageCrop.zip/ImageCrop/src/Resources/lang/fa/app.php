<?php

return [
    'imagecrop' => [
        'cancel' => 'لغو',
        'crop'  => 'برش',
    ],
];

