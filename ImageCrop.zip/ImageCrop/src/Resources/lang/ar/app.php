<?php

return [
    'imagecrop' => [
        'cancel' => 'إلغاء',
        'crop'  => 'تقليم',
    ],
];
