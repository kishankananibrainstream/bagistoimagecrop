<?php

return [
    'imagecrop' => [
        'cancel' => 'Annuler',
        'crop'  => 'Rogner',
    ],
];

