<?php

return [
    'imagecrop' => [
        'cancel' => 'ביטול',
        'crop'  => 'גזירה',
    ],
];

