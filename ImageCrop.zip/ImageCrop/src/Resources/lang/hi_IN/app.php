
<?php

return [
    'imagecrop' => [
        'cancel' => 'रद्द करें',
        'crop'  => 'काटें',
    ],
];
